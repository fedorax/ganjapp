FOR PREVIEW PLEASE TYPE 
(LingLengLang)

===========================================================
Please contact me before any commercial use.
My fonts for free use are allowed only in personal projects, and non-profit.
If you make money from using my fonts, Please purchase a commercial license.
CONTACT :
gasemraya@gmail.com


